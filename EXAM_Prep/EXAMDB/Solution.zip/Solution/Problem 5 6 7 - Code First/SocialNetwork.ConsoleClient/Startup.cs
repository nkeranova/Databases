﻿namespace SocialNetwork.ConsoleClient
{
    using System.Data.Entity;
    using System.Linq;
    using SocialNetwork.Data;

    public class Startup
    {
        public static void Main()
        {
           // Database.SetInitializer(new MigrateDatabaseToLatestVersion<SocialNetworkDBContext, Configuration>());
            
        }
    }
}
