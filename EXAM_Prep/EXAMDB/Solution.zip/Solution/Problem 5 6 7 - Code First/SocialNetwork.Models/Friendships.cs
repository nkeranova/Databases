﻿//namespace SocialNetwork.Models
//{
//    using System.Collections.Generic;
//    using System.ComponentModel.DataAnnotations;
//    using System.ComponentModel.DataAnnotations.Schema;
//
//    class Friendships
//    {
//        //private ICollection<Users> users;
//
//        //public Friendships()
//        //{
//        //    this.users = new HashSet<Users>();
//        //}
//
//        [Key]
//        public int Id { get; set; }
//
//        [Required]
//        public string FirstUser { get; set; }
//
//        [Required]
//        public string SecondtUser { get; set; }
//
//        //TODO: add approved and date
//        //public bool Approved { get; set; }
//
//        //public DateType ApprovedDate { get; set; }
//
//        //public virtual ICollection<Users> Users
//        //{
//        //    get { return this.users; }
//        //    set { this.users = value; }
//        //}
//    }
//}
//